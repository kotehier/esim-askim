function goLogin(){
  window.location.href = "/ask";
}